DSK INTERIORS WEBSITE — PREVIEW PACKAGE

Files:
- index.html: responsive mobile-first website
- assets/dsk-interiors-logo.png: crop of the existing DSK logo from the previously approved DSK technical handbook artwork

To preview:
1. Keep index.html and the assets folder together.
2. Open index.html in a modern browser.

To publish:
Upload index.html and the assets folder to a web host after registering/connecting dskinteriors.com.

Important:
- The domain has not been registered or connected by this package.
- Confirm the email address before publishing. It was entered as "abbavaramnagarjuna175@ gmail.com"; this draft removes the space to form abbavaramnagarjuna175@gmail.com.
- Replace illustrative hero stock photo with an approved real DSK project photo when available.
